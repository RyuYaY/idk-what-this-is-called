name = input("what is your name? ")
print("Hello "+ name)
action = input("What would you like to do today? ")
print("Did you say you want to "+ action)
input("yes or no? ") == True
print("hahahahah...me too bro, I wanna " + action)
nothing = input("haha")
print("Please tell me you're joking " + name)
lmao = input(" ")
print("I might cry " + lmao)
print("thank you for your time " + name)
print("can we continue to be friends? " + name)
continue_friendship = input(" ").lower()
if continue_friendship == "yes":
  print("Yes!, I'm not a failure")
else continue_friendship == "no":
print("Damn, Maybe I can find someone else to share my hopes of undying loyalty with")