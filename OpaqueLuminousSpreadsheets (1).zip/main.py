name = input("what is your name? ")
print("Hello "+ name)
action = input("What would you like to do today? ")
print("Did you say you want to "+ action)
input("yes or no? ") == True
print("hahahahah...me too bro, I wanna " + action)
